def saludar(nombre):
    return "Hola, {nombre}. Este es mi primer paquete pip."