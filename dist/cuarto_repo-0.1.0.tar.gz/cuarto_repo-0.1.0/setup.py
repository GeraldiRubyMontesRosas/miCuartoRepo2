from setuptools import setup, find_packages

setup(
    name='cuarto_repo',
    version='0.1.0',
    packages=find_packages(),
    description="Un paquete pip siempre de saludo",
    author='Ruby Montes',
    author_email='ruby.montes.rosas@ejemplo.com',
    url='https://github.com/GeraldiRubyMontesRosas/miCuartoRepo2#',
)